<?php
/**
 * Team Events
 *
 * @author 		ThemeBoy
 * @package 	SportsPress/Templates
 * @version     2.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! isset( $id ) )
	$id = get_the_ID();

$format = get_option( 'sportspress_team_events_format', 'blocks' );
if ( 'calendar' === $format )
	sp_get_template( 'event-calendar.php', array( 'team' => $id ) );
else
	sp_get_template( 'event-fixtures-results.php', array( 'team' => $id ) );
